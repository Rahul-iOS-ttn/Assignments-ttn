//
//  ViewController.swift
//  TTN_Greetings_APP
//
//  Created by TTN on 21/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

protocol ErrorViewProtocol { }
protocol LoggableProtocol { }
protocol RoundableProtocol { }
protocol BordableProtocol { }


extension ErrorViewProtocol where Self: UIViewController {
    var error: String {
        return "User not found"
    }
}

extension LoggableProtocol where Self: UIViewController {
    func verifyEmail(email: String) -> Bool {
        let emailVerificationRegex: String = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$"
        let validCheck = NSPredicate(format:"SELF MATCHES %@", emailVerificationRegex)
        return validCheck.evaluate(with: email)
    }
    func verifyPassword(password: String) -> Bool {
        let passwordVerificationRegex: String = "^(?=.*[A-Z].*[A-Z])(?=.*[!@#$&*])(?=.*[0-9].*[0-9])(?=.*[a-z].*[a-z].*[a-z]).{8}$"
        //        ^                         Start anchor
        //        (?=.*[A-Z].*[A-Z])        Ensure string has two uppercase letters.
        //        (?=.*[!@#$&*])            Ensure string has one special case letter.
        //        (?=.*[0-9].*[0-9])        Ensure string has two digits.
        //        (?=.*[a-z].*[a-z].*[a-z]) Ensure string has three lowercase letters.
        //        .{8}                      Ensure string is of length 8.
        //        $                         End anchor. password - AB@12cde
        
        let validCheck = NSPredicate(format:"SELF MATCHES %@", passwordVerificationRegex)
        
        return validCheck.evaluate(with: password)
    }
    
}


extension UIViewController {
    
    func showToast(message : String, font: UIFont) {
        
        let toastLabel = UILabel(frame: CGRect(x: self.view.frame.size.width/2 - 75, y: self.view.frame.size.height-100, width: 200, height: 35))
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        toastLabel.textColor = UIColor.white
        toastLabel.font = font
        toastLabel.textAlignment = .center;
        toastLabel.text = message
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 10;
        toastLabel.clipsToBounds  =  true
        self.view.addSubview(toastLabel)
        UIView.animate(withDuration: 4.0, delay: 0.1, options: .curveEaseOut, animations: {
            toastLabel.alpha = 0.0
        }, completion: {(isCompleted) in
            toastLabel.removeFromSuperview()
        })
    } }

extension RoundableProtocol where Self: UIView {
    func convertIntoRoundFormat() {}
}

extension BordableProtocol where Self: UIView {
    func addBorderElement() {}
}


class ViewController: UIViewController, LoggableProtocol {
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    
    var model: Model = Model()
    var employeeArray: [Employee] {
        return model.employees
    }
    var clientArray: [Client] {
        return model.clients
    }
    var userName: String = ""
    var email: String = ""
    var phoneNumber: String = ""
    var id: String = ""
    var imageOfUser: String = ""
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func onLoginPress () {
        if(self.verifyEmail(email: emailTextField.text ?? "") &&
            self.verifyPassword(password: passwordTextField.text ?? "")) {
            if (emailTextField.text!.contains("tothenew")){
//                employeeArray.filter { (emp) -> Bool in
//                    return emp.email
//                }
                for index in employeeArray where (emailTextField.text! == index.email) {
                    userName = index.fName
                    email = index.email
                    phoneNumber = index.phoneNumber
                    id = index.employeeId
                    imageOfUser = index.imageUser
                }
            } else {
                for index in clientArray where (emailTextField.text! == index.email) {
                    userName = index.name
                    email = index.email
                    phoneNumber = index.phoneNumber
                    id = index.id
                    imageOfUser = index.imageUser
                }
            }
            let vcObj = storyboard!.instantiateViewController(withIdentifier: "MixClientEmployeeViewController") as! MixClientEmployeeViewController
            vcObj.email = email
            vcObj.id = id
            vcObj.phoneNumber = phoneNumber
            vcObj.userName = userName
            vcObj.imageOfUser = imageOfUser
            navigationController?.pushViewController(vcObj, animated: true)
        } else {
            self.showToast(message: "Invalid email or password", font: .systemFont(ofSize: 12.0))
        }
        
    }
}

