//
//  MixClientEmployeeViewController.swift
//  TTN_Greetings_APP
//
//  Created by TTN on 24/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

struct General {
    var name: String
    var id: String
    var email: String
    var phoneNumber: String
    
    init(name: String, id: String, email: String, phoneNumber: String) {
        self.name = name
        self.id = id
        self.email = email
        self.phoneNumber = phoneNumber
    }
}


class MixClientEmployeeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var userName: String = ""
    var email: String = ""
    var phoneNumber: String = ""
    var id: String = ""
    var imageOfUser: String = ""
    @IBOutlet weak var PrimIdLabel: UILabel!
    @IBOutlet weak var PrimNameLabel: UILabel!
    @IBOutlet weak var myTableView: UITableView!
    @IBOutlet weak var PrimEmailLabel: UILabel!
    @IBOutlet weak var PrimContactLabel: UILabel!
    @IBOutlet weak var loggedInUserImage: UIImageView!
    
    var model: Model = Model()
    var employeeArray: [Employee] {
        return model.employees
    }
    var clientArray: [Client] {
        return model.clients
    }
    var gens: [General] = []
    //image
    
    func convertDat() {
        for idx in 0..<employeeArray.count {
            gens.append(General(name: employeeArray[idx].fName, id: employeeArray[idx].employeeId, email: employeeArray[idx].email, phoneNumber: employeeArray[idx].phoneNumber))
        }
        for idx in 0..<clientArray.count {
            gens.append(General(name: clientArray[idx].name, id: clientArray[idx].id, email: clientArray[idx].email, phoneNumber: clientArray[idx].phoneNumber))
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        convertDat()
        
        let nib = UINib(nibName: "MyTableViewCell", bundle: nil)
        
        myTableView.register(nib, forCellReuseIdentifier: "MyTableViewCell")
        
        myTableView.delegate = self
        myTableView.dataSource = self
        myTableView.reloadData()
        myTableView.layoutIfNeeded()
        PrimIdLabel.text = id
        PrimNameLabel.text = userName
        PrimEmailLabel.text = email
        PrimContactLabel.text = phoneNumber
        
        let image = UIImage(named: imageOfUser)
        loggedInUserImage.makeRounded()
        let borderImage = image?.addBorder(width: 5.0, color: .yellow)
        loggedInUserImage.image = borderImage
    }
    
    override func viewDidLayoutSubviews() {
        myTableView.heightAnchor.constraint(equalToConstant:
            myTableView.contentSize.height).isActive = true
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return gens.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = myTableView.dequeueReusableCell(withIdentifier: MyTableViewCell.identifier, for: indexPath) as! MyTableViewCell
        cell.transferData(element: gens[indexPath.row])
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.showToast(message: "Greetings to \(gens[indexPath.row].name) from \(userName)", font: .systemFont(ofSize: 12.0))
    }
    
}
