//
//  Model.swift
//  TTN_Greetings_APP
//
//  Created by TTN on 24/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import Foundation

extension Date {
    var currentDate: String {
        let joiningDate = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "dd.MM.yyyy"
        let result = formatter.string(from: joiningDate)
        return result
    }
}


struct Employee {
    var email: String
    var phoneNumber: String
    var employeeId: String
    var fName: String
    var lName: String
    var imageUser: String
    var userRole: String
    var joiningDate: String //extension for getting date
    var id: String
    var address: String
    
    init(email: String, phoneNumber: String, employeeId: String, fName: String, lName: String, imageUser: String, userRole: String, joiningDate: Date, id: String, address: String) {
        self.email = email
        self.phoneNumber = phoneNumber
        self.employeeId = employeeId
        self.fName = fName
        self.lName = lName
        self.imageUser = imageUser
        self.userRole = userRole
        self.joiningDate = joiningDate.currentDate
        self.id = id
        self.address = address
    }
}

struct Client {
    var email: String
    var name: String
    var phoneNumber: String
    var imageUser: String //extension for getting date
    var id: String
    var address: String
    
    init(email: String, phoneNumber: String, name: String, imageUser: String, id: String, address: String) {
        self.email = email
        self.name = name
        self.phoneNumber = phoneNumber
        self.imageUser = imageUser
        self.id = id
        self.address = address
    }
}

class Model: NSObject {
    var employees: [Employee] =
        [Employee.init(email: "rahul.sharma@tothenew.com", phoneNumber: "180236", employeeId: "1", fName: "Rahul", lName: "Sharma", imageUser: "kyubi", userRole: "Trainee",joiningDate: Date(), id: "1", address: "Delhi"),
         Employee.init(email: "aryan@tothenew.com", phoneNumber: "1712964", employeeId: "2", fName: "Aryan", lName: "Sethi", imageUser: "minion", userRole: "Trainee",joiningDate: Date() , id: "2", address: "Delhi"),
         Employee.init(email: "kavya@tothenew.com", phoneNumber: "123451254", employeeId: "3", fName: "Kavya", lName: "Casshyap", imageUser: "Naruto_kid", userRole: "Trainee",joiningDate: Date() , id: "3", address: "Delhi"),
         Employee.init(email: "harsh@tothenew.com", phoneNumber: "23675498", employeeId: "4", fName: "Harsh", lName: "Agarwal", imageUser: "naruto_standup", userRole: "Trainee",joiningDate: Date(), id: "4", address: "Delhi"),
         Employee.init(email: "vijender@tothenew.com", phoneNumber: "1346245634", employeeId: "5", fName: "Vijender", lName: "Negi", imageUser: "sasuke_power", userRole: "Trainee",joiningDate: Date(), id: "5", address: "Delhi")]

    var clients: [Client] =
        [Client.init(email: "annu@gmail.com", phoneNumber: "2039485", name: "Annu", imageUser: "sasuke standalone.jpeg", id: "1", address: "Banglore"),
         Client.init(email: "abhi@kakao.com", phoneNumber: "8914538", name: "Abhi", imageUser: "shinchan.jpeg", id: "2", address: "Pune"),
         Client.init(email: "isha@naver.com", phoneNumber: "126735", name: "Isha", imageUser: "FoodiePanda.jpeg", id: "3", address: "Chennai"),
         Client.init(email: "bajaj@yahoo.com", phoneNumber: "1234124", name: "Bajaj", imageUser: "serious_momentjpg", id: "4", address: "Hydrabad"),
         Client.init(email: "karan@outlook.com", phoneNumber: "123746", name: "Karan", imageUser: "naruto_serous.jpeg", id: "5", address: "America")
    ]

}
