//
//  CustomCollectionCell.swift
//  Collection View Application
//
//  Created by TTN on 19/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class CustomCollectionCell: UICollectionViewCell {
    @IBOutlet weak var label : UILabel!
    @IBOutlet weak var imageView : UIImageView!
    static let identifier = "CustomCollectionCell"
    
    static func nib() -> UINib {
        return UINib(nibName: "CustomCollectionCell", bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    public func configure(with model : Model){
        label.text = model.text
        imageView.image = UIImage(named: model.imageName)
    }
}
