//
//  ViewController.swift
//  Collection View Application
//
//  Created by TTN on 19/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var table : UITableView!
    
    var models = [Model]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        models.append(Model(text: "Foodie_Panda", imageName: "FoodiePanda"))
        models.append(Model(text: "In_Awe", imageName: "kung_fu_panda_inspired"))
        models.append(Model(text: "Banana", imageName: "minion"))
        models.append(Model(text: "Kid_Naruto", imageName: "Naruto_kid"))
        models.append(Model(text: "Shippuden_Duo", imageName: "Naruto_sasuke"))
        models.append(Model(text: "Angry", imageName: "Naruto_serous"))
        models.append(Model(text: "Shinchan", imageName: "shinchan_title"))
        models.append(Model(text: "Seriousness", imageName: "serious_moment"))
        
        table.register(CustomTableCellTableViewCell.nib(), forCellReuseIdentifier: CustomTableCellTableViewCell.identifier)
        table.delegate = self
        table.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return models.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = table.dequeueReusableCell(withIdentifier: CustomTableCellTableViewCell.identifier, for: indexPath) as! CustomTableCellTableViewCell
        cell.configure(with: models)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 180.0
    }

}

struct Model{
    let text : String
    let imageName : String
    
    init(text:String,imageName:String) {
        self.text = text
        self.imageName = imageName
    }
    
}
