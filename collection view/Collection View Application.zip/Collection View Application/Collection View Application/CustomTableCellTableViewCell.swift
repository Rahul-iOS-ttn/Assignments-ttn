//
//  CustomTableCellTableViewCell.swift
//  Collection View Application
//
//  Created by TTN on 19/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class CustomTableCellTableViewCell: UITableViewCell, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout

{
  
    

    static let identifier = "CustomTableCellTableViewCell"
    static func nib() -> UINib {
        return UINib(nibName: "CustomTableCellTableViewCell", bundle: nil)
    }
    
    @IBOutlet weak var CustomCollectionView : UICollectionView!
    
    var models = [Model]()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        CustomCollectionView.register(CustomCollectionCell.nib(), forCellWithReuseIdentifier: CustomCollectionCell.identifier )
        
        CustomCollectionView.delegate = self
        CustomCollectionView.dataSource = self
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
          return models.count
      }
      
    func configure(with models : [Model]){
        self.models = models
        CustomCollectionView.reloadData()
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = CustomCollectionView.dequeueReusableCell(withReuseIdentifier: CustomCollectionCell.identifier, for: indexPath) as! CustomCollectionCell
        cell.configure(with: models[indexPath.row])
        return cell
      }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 150, height: 150)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
