//
//  HorizontalStackUI.swift
//  Swift_UI
//
//  Created by TTN on 14/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import SwiftUI

struct HorizontalStackUI: View {
    var body: some View {
        HStack{
            Text("Assignment work").foregroundColor(.purple).font(.custom("CopperPlate", size: 35))
            Text("Battle Grounds").foregroundColor(.red)
        }
    }
}

struct HorizontalStackUI_Previews: PreviewProvider {
    static var previews: some View {
        HorizontalStackUI()
    }
}
