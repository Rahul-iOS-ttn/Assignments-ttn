//
//  ImageUI.swift
//  Swift_UI
//
//  Created by TTN on 14/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import SwiftUI

struct ImageUI: View {
    var body: some View{
        Image("TTN_PN").resizable()
            .aspectRatio(contentMode: .fit)
    }
}

struct ImageUI_Previews: PreviewProvider {
    static var previews: some View{
        ImageUI()
    }
}
