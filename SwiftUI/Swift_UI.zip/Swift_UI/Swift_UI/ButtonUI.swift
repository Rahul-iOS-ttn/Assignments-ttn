//
//  ButtonUI.swift
//  Swift_UI
//
//  Created by TTN on 14/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import SwiftUI

struct ButtonUI: View {
    var body: some View {
        Button(action: {
            
        }, label: {
            Text("ButtonUI")
                .foregroundColor(.red)
                .font(.system(size: 35))
        })
            .padding(.all, 30.0)
            .background(Color.green)
            .cornerRadius(25)
    }
}

struct ButtonUI_Previews: PreviewProvider {
    static var previews: some View {
        ButtonUI()
    }
}
