//
//  TextUI.swift
//  Swift_UI
//
//  Created by TTN on 14/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import SwiftUI

struct TextUI: View {
    var body: some View {
        Text("SwiftUI assignment by RS")
    }
}

struct TextUI_Previews: PreviewProvider {
    static var previews: some View {
        TextUI()
    }
}
