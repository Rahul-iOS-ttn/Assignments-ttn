//
//  PckerUI.swift
//  Swift_UI
//
//  Created by TTN on 14/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import SwiftUI

struct PckerUI: View {
    @State private var dateCurrent = Date()
    
    var body: some View {
        DatePicker("Please select the date", selection: $dateCurrent )
    }
}

struct PckerUI_Previews: PreviewProvider {
    static var previews: some View {
        PckerUI()
    }
}
