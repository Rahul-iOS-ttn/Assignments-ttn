//
//  GalleryViewController.swift
//  Gallery APP
//
//  Created by TTN on 19/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class GalleryViewController: UIViewController {
      var view1: Gallery_View = {
        let view = Gallery_View(with: .monkey)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
      }()
      
      var view2: Gallery_View = {
        let view = Gallery_View(with: .panda)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
      }()
      
      var view3: Gallery_View = {
        let view = Gallery_View(with: .owl)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
      }()
      
      var view4: Gallery_View = {
        let view = Gallery_View(with: .skeleton)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
      }()
      
      override func viewDidLoad() {
        super.viewDidLoad()
        setupViews()
        setupConstraints()
        view.backgroundColor = .white
      }
      
        // MARK: - Setting Views
      private func setupViews() {
        view.addSubviews(view1, view2, view3, view4)
      }
      
        
      // MARK: - Setting Constraints
      private func setupConstraints() {
        let safeArea = view.safeAreaLayoutGuide

        NSLayoutConstraint.activate([
          view1.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor),
          view1.topAnchor.constraint(equalTo: safeArea.topAnchor),
          view1.widthAnchor.constraint(equalTo: safeArea.widthAnchor, multiplier: 0.5),
          view1.heightAnchor.constraint(equalTo: safeArea.heightAnchor, multiplier: 0.5),

          view2.leadingAnchor.constraint(equalTo: view1.trailingAnchor),
          view2.topAnchor.constraint(equalTo: safeArea.topAnchor),
          view2.widthAnchor.constraint(equalTo: safeArea.widthAnchor, multiplier: 0.5),
          view2.heightAnchor.constraint(equalTo: safeArea.heightAnchor, multiplier: 0.5),
          view2.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor),

          view3.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor),
          view3.topAnchor.constraint(equalTo: view1.bottomAnchor),
          view3.widthAnchor.constraint(equalTo: safeArea.widthAnchor, multiplier: 0.5),
          view3.heightAnchor.constraint(equalTo: safeArea.heightAnchor, multiplier: 0.5),
          view3.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor),

          view4.leadingAnchor.constraint(equalTo: view3.trailingAnchor),
          view4.topAnchor.constraint(equalTo: view2.bottomAnchor),
          view4.widthAnchor.constraint(equalTo: safeArea.widthAnchor, multiplier: 0.5),
          view4.heightAnchor.constraint(equalTo: safeArea.heightAnchor, multiplier: 0.5),
          view4.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor),
        ])
      }
    }

    public extension UIView {
      func addSubviews(_ views: UIView...) {
        for view in views {
          addSubview(view)
        }
      }
}
