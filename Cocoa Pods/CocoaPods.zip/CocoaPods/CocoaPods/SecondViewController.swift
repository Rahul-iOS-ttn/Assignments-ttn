//
//  SecondViewController.swift
//  CocoaPods
//
//  Created by TTN on 22/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

import SVProgressHUD

extension UIImageView {
    func downloadedFrom(url: URL, contentMode mode: UIView.ContentMode = .scaleAspectFit) {
        contentMode = mode
        print("URL is here \(url)")
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() { [weak self] in
                self?.image = image
            }
        }.resume()
    }
    
    func downloaded(from link: String, contentMode mode: UIView.ContentMode = .scaleAspectFit) {
        guard let url = URL(string: link) else { return }
        downloadedFrom(url: url, contentMode: mode)
    }
}


class SecondViewController: UIViewController {
    @IBOutlet weak var imageViewContent: UIImageView!
    @IBOutlet weak var id: UILabel!
    @IBOutlet weak var author: UILabel!
    @IBOutlet weak var width: UILabel!
    @IBOutlet weak var height: UILabel!
    
    var cc: Stats?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        SVProgressHUD.show(withStatus: "It is working...")
        SVProgressHUD.dismiss(withDelay: 0.5)
        
        id.text = cc?.id
        author.text = cc?.author
        width.text = "\((cc?.width)!)"
        height.text = "\((cc?.height)!)"
        
        let urlString = (cc?.download_url)!
        let url = URL(string: urlString)!
        imageViewContent.downloadedFrom(url: url)
    }
}
