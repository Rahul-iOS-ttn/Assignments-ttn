//
//  SecondViewController.swift
//  CoreData_Recipe_demo
//
//  Created by TTN on 11/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit
import CoreData

class SecondViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var recipes = [Recipe]()
    var indexRecipe = [Int:Bool]()
    var favRecipes = [String?]()
    
    var managedObjectContext: NSManagedObjectContext!
    
    @IBOutlet weak var recipeField: UITextField!
    @IBOutlet weak var secretIngredientField: UITextField!
    @IBOutlet weak var genreField: UITextField!
    
    
    @IBOutlet weak var myTable: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        myTable.register(MyCustomTableViewCell.nib(), forCellReuseIdentifier: MyCustomTableViewCell.identifier)
        myTable.delegate = self
        myTable.dataSource = self
        managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        data()
    }
    
    func data(){
        let recipeRequest:NSFetchRequest<Recipe> = Recipe.fetchRequest()
        do {
            recipes = try managedObjectContext.fetch(recipeRequest)
            self.myTable.reloadData()
        }catch {
            print("Could not load data from database \(error.localizedDescription )")
        }
    }
    
    @IBAction func addRecipeButtonTapped(_ sender: Any) {
        
        let item = Recipe(context: managedObjectContext)
        item.dish_name = recipeField!.text
        item.secret_ingredient = secretIngredientField!.text
        item.genre = genreField!.text
        
        do {
            try self.managedObjectContext.save()
            self.data()
        }catch {
            print("Could not save data \(error.localizedDescription)")
        }
    }
    @IBAction func removeRecipeButtonTapped(_ sender: Any) {
        
        //         Create Fetch Request
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Recipe")
        
        // Create Batch Delete Request
        let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        
        do {
            try managedObjectContext.execute(batchDeleteRequest)
            self.myTable.reloadData()
        } catch {
            print("Not able to delete data \(error.localizedDescription)")
        }
        
        
    }
    
    
    @IBAction func logoutButtonTapped(_ sender: Any) {
        UserDefaults.standard.set(false, forKey: "ISUSERLOGGEDIN")
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let loginNavController = storyboard.instantiateViewController(identifier: "LoginNavController")
        
        (UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate)?.changeRootViewController(loginNavController)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return recipes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = myTable.dequeueReusableCell(withIdentifier: MyCustomTableViewCell.identifier, for: indexPath) as! MyCustomTableViewCell
        //think of a different way
        if indexRecipe[indexPath.row] == true{
            cell.cellImage.image = UIImage(named: "filledheart")
            cell.configureCustomCell(element: recipes[indexPath.row] )
        } else {
            cell.cellImage.image = UIImage(named: "heart")
            cell.configureCustomCell(element: recipes[indexPath.row] )
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = myTable.cellForRow(at: indexPath) as! MyCustomTableViewCell
        cell.cellImage.image = UIImage(named: "filledheart")
        favRecipes.append(cell.name!.text)
        //    print("fav list = \(favList)")
        NotificationCenter.default.post(name: Notification.Name(rawValue: notificationIdentifier), object: favRecipes)
        
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        let cell = myTable.cellForRow(at: indexPath) as! MyCustomTableViewCell
        cell.cellImage.image = UIImage(named: "heart")
        indexRecipe[indexPath.row] = false
    }
    
}
