//
//  MyCustomTableViewCell.swift
//  CoreData_Recipe_demo
//
//  Created by TTN on 11/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class MyCustomTableViewCell: UITableViewCell {
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var secretIngredient: UILabel!
    @IBOutlet weak var genre: UILabel!
    @IBOutlet weak var cellImage: UIImageView!
    static let identifier = "MyCustomTableViewCell"
    static func nib() -> UINib {
        return UINib(nibName: "MyCustomTableViewCell", bundle: nil)
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func configureCustomCell(element: Recipe){
        name!.text = element.dish_name
        secretIngredient!.text = element.secret_ingredient
        genre!.text = element.genre
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
