//
//  ThirdViewController.swift
//  CoreData_Recipe_demo
//
//  Created by TTN on 11/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

//First open this in the application for view to load


let notificationIdentifier = "notificatnotificationIdentifierionId"

class ThirdViewController: UIViewController{
    
    var favoriteRecipe =  [String?]()
    var tempList = [Int]()
    
    @IBOutlet weak var favoriteTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        favoriteTableView.dataSource = self
        favoriteTableView.delegate = self
        
//        favoriteTableView.register(MyCustomTableViewCell.nib(), forCellReuseIdentifier: MyCustomTableViewCell.identifier)
//        favoriteTableView.register(MyCustomTableViewCell.nib(), forCellReuseIdentifier: "Cell")
        
        NotificationCenter.default.addObserver(self,selector: #selector(doSomethingAfterNotified(notification:)),name: NSNotification.Name(rawValue: notificationIdentifier), object: nil)
    }
    
    @objc func doSomethingAfterNotified (notification: NSNotification) -> () {
        
        
        favoriteRecipe = notification.object as! [String?]
        //        print("\(favoriteList[0] ?? "hello")")
        favoriteTableView.reloadData()
    }
    
    
    
}


extension ThirdViewController: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return favoriteRecipe.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = favoriteTableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = favoriteRecipe[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50.0
    }
    
    
}
