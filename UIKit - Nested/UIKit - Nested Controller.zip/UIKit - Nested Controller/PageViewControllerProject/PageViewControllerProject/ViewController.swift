//
//  ViewController.swift
//  PageViewControllerProject
//
//  Created by TTN on 17/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPageViewControllerDataSource, UIPageViewControllerDelegate {
    
    
    
    var myControllers = [UIViewController]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let vc = UIViewController()
        vc.view.backgroundColor = .green
        myControllers.append(vc)
        
        let vc1 = UIViewController()
        vc1.view.backgroundColor = .darkGray
        myControllers.append(vc1)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        DispatchQueue.main.asyncAfter(deadline: .now()+2, execute: {
            
            self.presentPageVC()
            
        })
    }
    
    func presentPageVC() {
        guard let firstController = myControllers.first else {
            return
        }
        let vc = UIPageViewController()
        
        vc.delegate = self
        vc.dataSource = self
        vc.setViewControllers([firstController], direction: .forward, animated: true, completion: nil)
        
        present(vc, animated: true)
    }
    
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        
        guard let idx = myControllers.firstIndex(of: viewController), idx > 0 else {
            return nil
        }
        let before = idx - 1
        
        return myControllers[before]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        
        guard let idx = myControllers.firstIndex(of: viewController), idx < (myControllers.count - 1) else {
            return nil
        }
        let after = idx + 1
        
        return myControllers[after]
        
    }
    
}


