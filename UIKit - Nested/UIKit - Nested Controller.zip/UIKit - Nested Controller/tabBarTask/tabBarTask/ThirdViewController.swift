//
//  ThirdViewController.swift
//  tabBarTask
//
//  Created by TTN on 16/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    @IBOutlet weak var labelThird: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        labelThird.text = "Downloads"
    }
}
