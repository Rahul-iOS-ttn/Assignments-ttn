//
//  SecondViewController.swift
//  tabBarTask
//
//  Created by TTN on 16/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var labelSecond: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        labelSecond.text = "History"
    }
}
