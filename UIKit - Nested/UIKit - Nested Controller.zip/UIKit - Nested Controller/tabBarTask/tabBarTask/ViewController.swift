//
//  ViewController.swift
//  tabBarTask
//
//  Created by TTN on 16/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labelFirst: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        labelFirst.text = "Featured"
    }
}

