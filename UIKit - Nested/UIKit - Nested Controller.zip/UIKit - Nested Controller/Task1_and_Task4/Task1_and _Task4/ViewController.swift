//
//  ViewController.swift
//  Task1_and _Task4
//
//  Created by TTN on 16/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .cyan
        title = "Home Screen"
    }
}
class SecondViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .yellow
        title = "Game Screen"
    }
}
class ThirdViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .green
        title = "Work Screen"
    }
}
class FourthViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .lightGray
        title = "Settings Screen"
    }
}


class ViewController: UIViewController {
    
    private let fButton: UIButton = {
        let fButton = UIButton(frame: CGRect(x: 0, y: 0, width: 180, height: 60))
        fButton.setTitle("Press", for: .normal)
        fButton.backgroundColor = .green
        fButton.setTitleColor(.white, for: .normal)
        return fButton
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .darkGray
        view.addSubview(fButton)
        fButton.addTarget(self, action: #selector(buttonTapped), for: .touchUpInside)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        fButton.center = view.center
    }
    
    @objc func buttonTapped() {
        let tabBarViewController = UITabBarController()
        
        let firstViewController = UINavigationController(rootViewController: FirstViewController())
        let secondViewController = UINavigationController(rootViewController: SecondViewController())
        let thirdViewController = UINavigationController(rootViewController: ThirdViewController())
        let fourthViewController = UINavigationController(rootViewController: FourthViewController())
        firstViewController.title = "Home Screen"
        secondViewController.title = "Game Screen"
        thirdViewController.title = "Location Screen"
        fourthViewController.title = "Settings screen"
        tabBarViewController.setViewControllers([firstViewController, secondViewController, thirdViewController, fourthViewController], animated: true)
        
        guard let tabBarItems = tabBarViewController.tabBar.items else {
            return
        }
        
        let image = ["house", "play", "location", "gear"]
        
        for i in 0..<tabBarItems.count {
            tabBarItems[i].image = UIImage(systemName: image[i])
        }
        
        tabBarViewController.modalPresentationStyle = .fullScreen
        present(tabBarViewController, animated: true)
    }


}

