//
//  ViewController.swift
//  shadow_and_round
//
//  Created by TTN on 17/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {
    
    @IBOutlet weak var shadowView : UIView!
    @IBOutlet weak var label : UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        label.text = "Sample of shadow and curve view"
        shadowView.layer.cornerRadius = 12.0
        shadowView.layer.shadowColor = UIColor.init(white: 220.0/255.0, alpha: 1.5).cgColor
        shadowView.layer.shadowOpacity = 0.8
        shadowView.layer.shadowRadius = 5.0
        shadowView.layer.shadowOffset = CGSize(width: -10, height: 10)
        
    }
    
    
    
}

