//
//  ViewController.swift
//  ImageCircular
//
//  Created by TTN on 14/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//
import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var circularImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        circularImage.layer.borderWidth = 1
        circularImage.layer.masksToBounds = false
        circularImage.layer.borderColor = UIColor.white.cgColor
        circularImage.layer.cornerRadius = circularImage.frame.size.height/2
        circularImage.clipsToBounds = true
    }
    override func willTransition(to newCollection: UITraitCollection, with coordinator: UIViewControllerTransitionCoordinator) {
    }
}

