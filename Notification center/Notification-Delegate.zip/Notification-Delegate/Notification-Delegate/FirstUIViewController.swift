//
//  FirstUIViewController.swift
//  Notification-Delegate
//
//  Created by TTN on 05/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

protocol FirstViewDelegate: class {
    func RecievingValues(_ data: [String: String?])
}



class FirstUIViewController: UIViewController {

 weak var delegate: FirstViewDelegate?
    
    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var designation: UITextField!
    
    @IBOutlet weak var digitalSignature: UITextField!
    
    var data: [String: String?] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func dataButtonTapped(_ sender: Any) {
    
        let data1: String? = name!.text
        let data2: String? = designation!.text
        let data3: String? = digitalSignature!.text
        
        data = ["name":data1,"designation":data2,"digitalSignature":data3]

        dismiss(animated: true) {
            self.delegate?.RecievingValues(self.data)
        }
    
    }

}
