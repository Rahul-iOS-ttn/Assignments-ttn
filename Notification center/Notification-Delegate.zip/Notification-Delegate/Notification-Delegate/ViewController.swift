//
//  ViewController.swift
//  Notification-Delegate
//
//  Created by TTN on 05/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

struct StructureOfData {
    var name: String?
    var designation: String?
    var digitalSignature: String?
    
    init(name: String?, designation: String?, digitalSignature: String?) {
        self.name = name
        self.designation = designation
        self.digitalSignature = digitalSignature
    }
}

class ViewController: UIViewController {

   @IBOutlet weak var myTable: UITableView!
    
    var recievedData: [String:String?] = [:]
    var dictValues: [StructureOfData] = []
    var str: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        navigationItem.title = "Information Provider"
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "+", style: .plain, target: self, action: #selector(insert))
        myTable.register(MyCustomTableViewCell.nib(), forCellReuseIdentifier: MyCustomTableViewCell.identifier)
            myTable.delegate = self
            myTable.dataSource = self
    }
    @objc func insert() {
        let vc = storyboard?.instantiateViewController(identifier: "first") as! FirstUIViewController
        self.present(vc, animated: true, completion: nil)
        vc.delegate = self

    }
}

extension ViewController: FirstViewDelegate, UITableViewDelegate, UITableViewDataSource {
    
    func RecievingValues(_ data: [String : String?]) {
        let structure = StructureOfData(name: data["name"] ?? "", designation: data["designation"] ?? "", digitalSignature: data["digitalSignature"] ?? "")
        dictValues.append(structure)
        myTable.reloadData()
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return dictValues.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = myTable.dequeueReusableCell(withIdentifier: MyCustomTableViewCell.identifier, for: indexPath) as! MyCustomTableViewCell

        cell.configureMyFunction(element: dictValues[indexPath.row])
            return cell
    }
    
}


