//
//  MyCustomTableViewCell.swift
//  Notification-Delegate
//
//  Created by TTN on 05/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class MyCustomTableViewCell: UITableViewCell {
     
     @IBOutlet weak var name: UILabel!
     
     @IBOutlet weak var designation: UILabel!
     
     @IBOutlet weak var digitalSignature: UILabel!
     
     static let identifier = "MyCustomTableViewCell"
             
         static func nib() -> UINib{
             return UINib(nibName: "MyCustomTableViewCell", bundle: nil)
         }
     
     override func awakeFromNib() {
         super.awakeFromNib()
         // Initialization code
     }

      func configureMyFunction(element: StructureOfData){

         name!.text = element.name
         designation!.text = element.designation
         digitalSignature!.text = element.digitalSignature
         
         }
     
     override func setSelected(_ selected: Bool, animated: Bool) {
         super.setSelected(selected, animated: animated)

         // Configure the view for the selected state
     }
     
    
     
}
