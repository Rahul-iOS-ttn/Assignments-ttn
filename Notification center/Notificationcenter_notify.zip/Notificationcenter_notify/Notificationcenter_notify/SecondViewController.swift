//
//  SecondViewController.swift
//  Notificationcenter_notify
//
//  Created by TTN on 05/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

let notificationIdentifier = "notificatnotificationIdentifierionId"

class SecondViewController: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var backgroundImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Second View Controller"
        NotificationCenter.default.addObserver(self,selector: #selector(doSomethingAfterNotified),name: NSNotification.Name(rawValue: notificationIdentifier), object: nil)
        
    }
    
    @objc func doSomethingAfterNotified () -> () {
        
        self.view.backgroundColor = UIColor.yellow
        titleLabel!.text = "Notification Received"
        
        let image = UIImage(named: "annie-spratt-IBFqPGfby2s-unsplash")
        backgroundImage.image = image
    }
    
    @IBAction func buttonNextTapped(_ sender: Any) {
        
        let vc: ThirdViewController = self.storyboard?.instantiateViewController(withIdentifier: "TVC") as! ThirdViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    deinit{
        
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: notificationIdentifier), object: nil)
        
    }
}
