//
//  ViewController.swift
//  Notificationcenter_notify
//
//  Created by TTN on 05/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var backgroundImage: UIImageView!
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.title = "First VC"
        NotificationCenter.default.addObserver(self,selector: #selector(doSomethingAfterNotified),name: NSNotification.Name(rawValue: notificationIdentifier), object: nil)
        
        
    }
    
    @objc func doSomethingAfterNotified() {
        //        print("I've been notified")
        self.view.backgroundColor = UIColor.yellow
        titleLabel!.text = "Notification received"
        let image = UIImage(named: "annie-spratt-IBFqPGfby2s-unsplash")
        backgroundImage.image = image
    }
    
    
    @IBAction func buttonNavigateToNextTapped(_ sender: Any) {
        
        let vc: SecondViewController = self.storyboard?.instantiateViewController(withIdentifier: "SVC") as! SecondViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    deinit{
        
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: notificationIdentifier), object: nil)
        
    }
    
}

