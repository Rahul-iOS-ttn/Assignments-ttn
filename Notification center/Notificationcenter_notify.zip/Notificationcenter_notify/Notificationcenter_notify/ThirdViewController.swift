//
//  ThirdViewController.swift
//  Notificationcenter_notify
//
//  Created by TTN on 05/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Third View Controller"
        
    }
    
    @IBAction func notifyButtonTapped(_ sender: Any) {
        titleLabel!.text = "Notification Received. Go back"
        NotificationCenter.default.post(name: Notification.Name(rawValue: notificationIdentifier), object: self)
    }
    
}
