//
//  ViewController.swift
//  Alert
//
//  Created by TTN on 06/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

  override func viewDidLoad() {
    
    //Steps for running the program
    //Run the application for the first time and give permission
    //After giving permission stop project and run again
    //as the application runs close the application before 5 seconds. by clicking on home button
    //wait and notification will be received after which you can drag down the notification bar to dismiss the notification.
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let notificationCenter = UNUserNotificationCenter.current()
             
        notificationCenter.requestAuthorization(options: [.alert, .sound]) { (granted, error) in }
             
            
        let content = UNMutableNotificationContent()
        content.title = "Notification from the notification center!"
        content.body = "Drag me down for dismissing me!!!"
        content.sound = UNNotificationSound.defaultCritical
        content.categoryIdentifier = "actionCategory"
        content.badge = 2
        
        let dismissAction = UNNotificationAction(identifier:"dismiss",
            title:"Dismiss",options:[])

        let category = UNNotificationCategory(identifier: "actionCategory",
             actions: [dismissAction],
            intentIdentifiers: [], options: [])

        UNUserNotificationCenter.current().setNotificationCategories([category])
             
        let date = Date().addingTimeInterval(5)
             
        let dateComponents = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second], from: date)
             
        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
             
        let uuidString = UUID().uuidString
             
        let request = UNNotificationRequest(identifier: uuidString, content: content, trigger: trigger)
             
             
        notificationCenter.add(request) { (error) in }
        
    }

}

