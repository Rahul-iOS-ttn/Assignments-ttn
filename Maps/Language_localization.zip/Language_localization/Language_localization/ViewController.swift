//
//  ViewController.swift
//  Language_localization
//
//  Created by TTN on 09/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var userStateLabel: UILabel!
    @IBOutlet weak var userCountryLabel: UILabel!
    @IBOutlet weak var userBirthLabel: UILabel!
    @IBOutlet weak var userWinningsLabel: UILabel!
    
    
    
    @IBOutlet weak var segmentControl: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonSelectSegmentClick(_ sender: UISegmentedControl) {
        
        if segmentControl.selectedSegmentIndex == 0 {
            //English
//            languageChanged(language: "en")
            userNameLabel.text = "NameKey".localizableString(loc: "en")
            userStateLabel.text = "StateKey".localizableString(loc: "en")
            userCountryLabel.text = "CountryKey".localizableString(loc: "en")
            userBirthLabel.text = "DOBKey".localizableString(loc: "en")
            userWinningsLabel.text = "LotteryWonKey".localizableString(loc: "en")
        }else if segmentControl.selectedSegmentIndex == 1 {
            //German
//            languageChanged(language: "de")
            userNameLabel.text = "NameKey".localizableString(loc: "de")
            userStateLabel.text = "StateKey".localizableString(loc: "de")
            userCountryLabel.text = "CountryKey".localizableString(loc: "de")
            userBirthLabel.text = "DOBKey".localizableString(loc: "de")
            userWinningsLabel.text = "LotteryWonKey".localizableString(loc: "de")
        } else {
            //Spanish
//            languageChanged(language: "es")
            userNameLabel.text = "NameKey".localizableString(loc: "es")
            userStateLabel.text = "StateKey".localizableString(loc: "es")
            userCountryLabel.text = "CountryKey".localizableString(loc: "es")
            userBirthLabel.text = "DOBKey".localizableString(loc: "es")
            userWinningsLabel.text = "LotteryWonKey".localizableString(loc: "es")
        }
    }
//    func languageChanged(language: String){
//        userNameLabel.text = "NameKey".localizableString(loc: language)
//        userStateLabel.text = "StateKey".localizableString(loc: language)
//        userCountryLabel.text = "CountryKey".localizableString(loc: language)
//        userBirthLabel.text = "DOBKey".localizableString(loc: language)
//        userWinningsLabel.text = "LotteryWonKey".localizableString(loc: language)
//    }
}

extension String {
    func localizableString(loc: String) -> String {
        let path = Bundle.main.path(forResource: loc, ofType: "lproj")
        let bundle = Bundle(path: path!)
        return NSLocalizedString(self, tableName: nil, bundle: bundle!, value: "", comment: "")
    }
}
