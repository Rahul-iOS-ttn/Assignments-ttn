//
//  model.swift
//  mapkit_
//
//  Created by TTN on 10/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import Foundation

struct model {
    var image: String
    var content: String
    
    init(image: String, content: String) {
        self.image = image
        self.content = content
    }
}


class modelData: NSObject {
    
    var location: String = ""
    
    var dmz: model = model.init(image: "DMZ", content: "Amongst famous South Korea attractions, The DMZ is one of the most famous places to visit in South Korea to get a better understanding of the conflict between North and South Korea & the current state of affairs. The DMZ is full of interesting sites that make for an engaging lesson in modern history. You can take a peek into North Korea at the Observation Post and feel the rush of adventure while walking through the Infiltration Tunnel. It is advisable to take a guided tour that includes a visit to the Joint Security Area (JSA).")
    
    var busan: model = model.init(image: "Haedong Yonggungsa temple", content: "This second largest city of South Korea is known across the world for hosting Asia’s largest International film festival. Busan is an interesting amalgamation of skyscrapers, majestic mountains, beautiful beaches and magnificent Buddhist temples and amongst the best places to visit in South Korea. Amongst the popular places to visit in Korea Busan is the Haedong Yonggungsa temple along the coast and the interesting Jagalchi fish market. Foodies can relish the sea food spread at the numerous restaurants and enjoy local delicacies at the ubiquitous street food stalls.")
    
    var gyeongju: model = model.init(image: "gyeongju", content: "One of the best places to go in South Korea, the coastal city of Gyeongju, often called an open-air museum, is one of the best things to do in South Korea to discover its traditional roots and rich heritage. The erstwhile capital of the ancient Silla kingdom, Gyeongju is a treasure trove of cultural and historical sites and ruins going back to a thousand years. With the UNESCO world heritage site, Bulguksa temple and the National Museum with its unparalleled collection of artefacts, this city gives you a glimpse into South Korea’s cultural roots.")
    
    var suwon: model = model.init(image: "Hwaseong Fortress", content: "Capital of the Gyeonggi province bordering Seoul, Suwon is known for its unique Hwaseong Fortress with its imposing stone walls and impressive archways and this has made it one of the best places to visit in Korea. Built by the Joseon dynasty the fortresses wall is a UNESCO world heritage site with four pagoda-style gates, artillery towers and observation decks. Another magnificent structure at the site is the Hwaseong Haenggung Palace. With all that said, don’t forget to indulge in shopping in Suwon. With many more exciting things to do, Suwon is one of the top places to visit in South Korea.")
    var jeonju: model = model.init(image: "jeonju", content: "If you are wondering about where to go in South Korea, then Jeonju is the answer! During the reign of the Joseon Dynasty the place happened to be the spiritual capital. It still has many temples and museums and is one of the best places to know about the rich and fascinating history of the country. If you are a history buff and wish to see traditional homes dating back to the early 20th century then make sure you stop at Jeonju and have a good time.")
    
    func displayData(location: String) -> model {
        
        switch location {
        case "dmz":
            return dmz
        case "busan":
            return busan
        case "gyeongju":
            return gyeongju
        case "suwon":
            return suwon
        case "jeonju":
            return jeonju   
        default:
            return busan
        }
    }
}
