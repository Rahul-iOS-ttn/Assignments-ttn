//
//  InfoViewController.swift
//  mapkit_
//
//  Created by TTN on 10/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class InfoViewController: UIViewController {

    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var content: UITextView!
    
    var location: String = ""
    var dataModel = modelData()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let imagecoming = UIImage(named: dataModel.displayData(location: location).image)
        image.image = imagecoming
        
        content.text = dataModel.displayData(location: location).content
        
        // Do any additional setup after loading the view.
    }
    
    

}
