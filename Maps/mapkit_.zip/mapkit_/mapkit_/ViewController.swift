//
//  ViewController.swift
//  mapkit_
//
//  Created by TTN on 10/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKAnnotation , CLLocationManagerDelegate{
    //coordinates of Busan will be here
    var coordinate: CLLocationCoordinate2D = CLLocationCoordinate2D(latitude:35.1883 , longitude: 129.2233)
    
    private let locationManager = CLLocationManager()
   
    
    let dmzAnnotation = CLLocationCoordinate2D(latitude: 37.9536, longitude: 126.6698)
    
    let busanAnnotation = CLLocationCoordinate2D(latitude: 35.1883, longitude: 129.2233)
    
    let gyeongjuAnnotation = CLLocationCoordinate2D(latitude: 35.8562, longitude: 129.2247)
    
    let suwonAnnotation = CLLocationCoordinate2D(latitude: 37.2871, longitude: 127.0119)
    
    let jeonjuAnnotation = CLLocationCoordinate2D(latitude: 35.8242, longitude: 127.1480)
    
    
    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureLocationServices()
        // Do any additional setup after loading the view.
        
        let annotation1 = MKPointAnnotation()
        annotation1.coordinate = dmzAnnotation
        annotation1.title = "DMZ"
        annotation1.subtitle = "Engage With Modern History"
        mapView.addAnnotation(annotation1)
        
        let annotation2 = MKPointAnnotation()
        annotation2.coordinate = busanAnnotation
        annotation2.title = "Busan"
        annotation2.subtitle = "Something For Everyone"
        mapView.addAnnotation(annotation2)
        
        let annotation3 = MKPointAnnotation()
        annotation3.coordinate = gyeongjuAnnotation
        annotation3.title = "Gyeongju"
        annotation3.subtitle = "A Treasure Trove Of Cultural Sites"
        mapView.addAnnotation(annotation3)
        
        let annotation4 = MKPointAnnotation()
        annotation4.coordinate = suwonAnnotation
        annotation4.title = "Suwon"
        annotation4.subtitle = "Home To A UNESCO World Heritage Site"
        mapView.addAnnotation(annotation4)
        
        let annotation5 = MKPointAnnotation()
        annotation5.coordinate = jeonjuAnnotation
        annotation5.title = "Jeonju"
        annotation5.subtitle = "With A Rich And Fascinating History"
        mapView.addAnnotation(annotation5)
        
        createPath(busanAnnotation: busanAnnotation, suwonAnnotation: jeonjuAnnotation)
        
        self.mapView.delegate = self
        
        let coordinateRegion = MKCoordinateRegion(center: busanAnnotation, latitudinalMeters: 1000, longitudinalMeters: 1000)
        self.mapView.setRegion(coordinateRegion, animated: true)
        
        let circle = MKCircle(center: busanAnnotation, radius: 800)
        self.mapView.addOverlay(circle)
        
        let circle1 = MKCircle(center: suwonAnnotation, radius: 800)
        self.mapView.addOverlay(circle1)
        
    }
    
    func createPath(busanAnnotation: CLLocationCoordinate2D, suwonAnnotation: CLLocationCoordinate2D) {
        
        //Route between destinations
        
        let busanPlacemark = MKPlacemark(coordinate: busanAnnotation, addressDictionary: nil)
        
        let suwonPlacemark = MKPlacemark(coordinate: suwonAnnotation, addressDictionary: nil)
        
        let busanMapItem = MKMapItem(placemark: busanPlacemark)
        let suwonMapItem = MKMapItem(placemark: suwonPlacemark)
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = busanMapItem
        directionRequest.destination = suwonMapItem
        directionRequest.transportType = .automobile
        
        let direction = MKDirections(request: directionRequest)
        
        direction.calculate{ (response, error) in
            guard let response = response else {
                if let error = error {
                    print("ERROR FOUND: \(error.localizedDescription)")
                }
                return
            }
            
            let route = response.routes[0]
            self.mapView.addOverlay(route.polyline, level: MKOverlayLevel.aboveRoads)
            
            let rect = route.polyline.boundingMapRect
            
            self.mapView.setRegion(MKCoordinateRegion(rect), animated: true)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    private func configureLocationServices() {
        locationManager.delegate = self
        
        let status = CLLocationManager.authorizationStatus()
        
        if status == .notDetermined {
            locationManager.requestWhenInUseAuthorization()
        } else if status == .authorizedWhenInUse || status == .authorizedAlways {
            beginLocationUpdates(locationManager: locationManager)
            
        }
    }
    
    private func beginLocationUpdates(locationManager: CLLocationManager) {
        mapView.showsUserLocation = true
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.startUpdatingLocation()
    }
    
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error.localizedDescription)
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        print(status)
    }
    
}



extension ViewController: MKMapViewDelegate {
    
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard annotation is MKPointAnnotation else { return nil }
        let identifier = "Annotation"
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
        if annotationView == nil {
            annotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            annotationView!.canShowCallout = true
            let btn = UIButton(type: .detailDisclosure)
            annotationView?.rightCalloutAccessoryView = btn
        } else {
            annotationView!.annotation = annotation
        }
        return annotationView
    }
    
    func mapView(_ mapView: MKMapView, didAdd views: [MKAnnotationView]) {
        if let annotation = views.first(where: { $0.reuseIdentifier == "Annotation" })?.annotation {
            mapView.selectAnnotation(annotation, animated: true)
        }
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        
        //how to view a particular annotation..
        
        
        let vc: InfoViewController = self.storyboard?.instantiateViewController(withIdentifier: "InfoViewController") as! InfoViewController
        //!jugaad
        vc.location = (((view.annotation?.title) ?? "busan") ?? "busan").lowercased()
        self.navigationController?.pushViewController(vc, animated: true)
        
        
    }
    
    
    internal func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        
        if overlay.isKind(of: MKPolyline.self) {
            let rendere = MKPolylineRenderer(overlay: overlay)
            rendere.lineWidth = 7
            rendere.strokeColor = .systemBlue
            return rendere
            
        }
        
        if overlay.isKind(of: MKCircle.self){
            let circleRenderer = MKCircleRenderer(overlay: overlay)
            circleRenderer.fillColor = UIColor.systemBlue.withAlphaComponent(0.6)
            circleRenderer.strokeColor = UIColor.red
            circleRenderer.lineWidth = 6
            return circleRenderer
        }
        
        return MKOverlayRenderer(overlay: overlay)
    }
    
}
