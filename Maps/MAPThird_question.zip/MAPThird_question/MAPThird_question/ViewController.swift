//
//  ViewController.swift
//  MAPThird_question
//
//  Created by TTN on 10/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation


class ViewController: UIViewController {
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var loader: UIActivityIndicatorView!
    
    var locationName = "Current location"
    //    var currentCoordinate : CLLocationCoordinate2D = .init()
    fileprivate let locationManager: CLLocationManager = {
        let manager = CLLocationManager()
        manager.requestWhenInUseAuthorization()
        return manager
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUpMapView()
        self.setUpView()
    }
    
    func setUpView(){
        imageView.isHidden = true
        loader.isHidden = true
        loader.stopAnimating()
    }
    
    func fetchImage() {
        let imageURL: URL = URL(string: "http://www.newsonair.com/writereaddata/News_Pictures/NAT/2018/Nov/NPIC-201811142185.jpg")!
        
        (URLSession(configuration: URLSessionConfiguration.default)).dataTask(with: imageURL, completionHandler: { (imageData, response, error) in
            
            if let data = imageData {
                print("Did download image data")
                
                DispatchQueue.main.async {
                    self.imageView.isHidden = false
                    self.button.setTitle("Hide Image", for: .normal)
                    self.loader.isHidden = true
                    self.loader.stopAnimating()
                    self.imageView.image = UIImage(data: data)
                }
            }
            else if let err = error{
                DispatchQueue.main.async {
                    self.loader.isHidden = true
                    self.loader.stopAnimating()
                    self.showAlert(msg: err.localizedDescription)
                }
                
            }
        }).resume()
    }
    
    
    //MARK: - Setup Methods
    func setUpMapView() {
        mapView.showsUserLocation = true
        mapView.showsCompass = true
        mapView.showsScale = true
        mapView.delegate = self
        mapView.isZoomEnabled = true
        mapView.mapType = .standard
        self.getUsercurrentLocation()
    }
    
    //MARK: - User Location
    func getUsercurrentLocation() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        if #available(iOS 11.0, *) {
            locationManager.showsBackgroundLocationIndicator = true
        }
        locationManager.startUpdatingLocation()
    }
    
    
    func addAnnotationsOnMapView(cordinates: CLLocationCoordinate2D) {
        mapView.annotations.dropFirst()
        let currentLocationAnnotation = MKPointAnnotation()
        currentLocationAnnotation.title = locationName
        currentLocationAnnotation.subtitle = "Sub Annotation Title"
        currentLocationAnnotation.coordinate = cordinates
        mapView.addAnnotation(currentLocationAnnotation)
    }
    
    
    func geocode(latitude: Double, longitude: Double)  {
        CLGeocoder().reverseGeocodeLocation(CLLocation(latitude: latitude, longitude: longitude)) { (placemarksArray, error) in
            if (error) == nil {
                if placemarksArray!.count > 0 {
                    let placemark = placemarksArray?.first
                    let address = "\(placemark?.subThoroughfare ?? ""), \(placemark?.thoroughfare ?? ""), \(placemark?.locality ?? ""), \(placemark?.subLocality ?? ""), \(placemark?.administrativeArea ?? ""), \(placemark?.postalCode ?? ""), \(placemark?.country ?? "")"
                    let city = (placemark?.locality ?? "")
                    let country = (placemark?.country ?? "")
                    self.locationName = country
                    self.addAnnotationsOnMapView(cordinates: self.mapView.annotations.first?.coordinate ?? .init())
                    print ("\(address)")
                    print (self.locationName)
                    
                }
            }
        }
    }
    
    func showAlert(msg: String) {
        let ac = UIAlertController(title: msg, message: nil, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(ac, animated: true)
    }
    
    @IBAction func showImageButtonTapped(_ sender: Any) {
        if imageView.isHidden {
            
            let status: CLAuthorizationStatus = CLLocationManager.authorizationStatus()
            if (status == .authorizedWhenInUse || status == .authorizedAlways)  && "United States" == locationName {
                loader.isHidden = false
                loader.startAnimating()
                fetchImage()
            } else {
                showAlert(msg: "This feature is not supported  in your country")
            }
        } else {
            button.setTitle("Show Image", for: .normal)
            imageView.isHidden = true
        }
    }
}

//MARK: - CLLocationManagerDelegate Methods
extension ViewController : CLLocationManagerDelegate{
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations.last! as CLLocation
        let currentLocation = location.coordinate
        //        currentCoordinate = currentLocation
        self.addAnnotationsOnMapView(cordinates: currentLocation)
        self.geocode(latitude: currentLocation.latitude, longitude: currentLocation.longitude)
        
        let coordinateRegion = MKCoordinateRegion(center: currentLocation, latitudinalMeters: 800, longitudinalMeters: 800)
        mapView.setRegion(coordinateRegion, animated: true)
        
        let circle = MKCircle(center: currentLocation, radius: 300)
        mapView.addOverlay(circle)
        locationManager.stopUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error.localizedDescription)
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        print(status)
    }
}


extension ViewController: MKMapViewDelegate {
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard annotation is MKPointAnnotation else { return nil }
        let identifier = "Annotation"
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
        if annotationView == nil {
            annotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            annotationView!.canShowCallout = true
            let btn = UIButton(type: .detailDisclosure)
            annotationView?.rightCalloutAccessoryView = btn
        } else {
            annotationView!.annotation = annotation
        }
        return annotationView
    }
    
    func mapView(_ mapView: MKMapView, didAdd views: [MKAnnotationView]) {
        if let annotation = views.first(where: { $0.reuseIdentifier == "Annotation" })?.annotation {
            mapView.selectAnnotation(annotation, animated: true)
        }
    }
    
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        
        showImageButtonTapped(button as Any)
        //        let vc: newViewController = self.storyboard?.instantiateViewController(withIdentifier: "newViewController") as! newViewController
        //        vc.currentCountryName = locationName
        //        self.navigationController?.pushViewController(vc, animated: true)
        
        
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if overlay.isKind(of: MKCircle.self){
            let circleRenderer = MKCircleRenderer(overlay: overlay)
            circleRenderer.fillColor = UIColor.black.withAlphaComponent(0.5)
            circleRenderer.strokeColor = UIColor.red
            circleRenderer.lineWidth = 5
            return circleRenderer
        }
        return MKOverlayRenderer(overlay: overlay)
    }
}

