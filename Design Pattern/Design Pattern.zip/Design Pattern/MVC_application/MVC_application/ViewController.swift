//
//  ViewController.swift
//  MVC_application
//
//  Created by TTN on 27/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

struct Client {
    var email: String
    var name: String
    
    init(email: String, name: String) {
        self.email = email
        self.name = name
    }
}

var clients: [Client] =
    [Client.init(email: "annu@gmail.com", name: "Annu"),
     Client.init(email: "abhi@kakao.com", name: "Abhi"),
     Client.init(email: "isha@naver.com", name: "Isha"),
     Client.init(email: "bajaj@yahoo.com", name: "Bajaj"),
     Client.init(email: "karan@outlook.com", name: "Karan")
]

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var myTable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        myTable.register(MyCustomTableViewCell.nib(), forCellReuseIdentifier: MyCustomTableViewCell.identifier)
        myTable.delegate = self
        myTable.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return clients.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = myTable.dequeueReusableCell(withIdentifier: MyCustomTableViewCell.identifier, for: indexPath) as! MyCustomTableViewCell
        
        cell.configureMyFunction(element: clients[indexPath.row])
        return cell
    }
    
    
    
}
