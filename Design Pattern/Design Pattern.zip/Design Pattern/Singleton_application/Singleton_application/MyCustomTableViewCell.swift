//
//  MyCustomTableViewCell.swift
//  Singleton_application
//
//  Created by TTN on 26/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class MyCustomTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var nameOfLabel: UILabel!
    @IBOutlet weak var genericLabel: UILabel!
    static let identifier = "MyCustomTableViewCell"
           
       static func nib() -> UINib{
           
           return UINib(nibName: "MyCustomTableViewCell", bundle: nil)
           
       }
       override func awakeFromNib() {
           super.awakeFromNib()
           // Initialization code
           
           
       }
       
       func configureMyFunction1(element: Employee){
           nameOfLabel.text = element.fName
           genericLabel.text = element.email
       }
    
        func configureMyFunction2(element: Employee){
            nameOfLabel.text = element.fName
            genericLabel.text = element.address
        }
    
        func configureMyFunction3(element: Employee){
            nameOfLabel.text = element.fName
            genericLabel.text = element.employeeId
        }
       
       override func setSelected(_ selected: Bool, animated: Bool) {
           super.setSelected(selected, animated: animated)

           // Configure the view for the selected state
       }
}
