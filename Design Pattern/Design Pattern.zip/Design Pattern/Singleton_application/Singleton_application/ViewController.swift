//
//  ViewController.swift
//  Singleton_application
//
//  Created by TTN on 26/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

struct Employee {
    var email: String
    var employeeId: String
    var fName: String
    var address: String
    
    init(email: String, employeeId: String, fName: String, address: String) {
        self.email = email
        self.employeeId = employeeId
        self.fName = fName
        self.address = address
    }
}

struct Client {
    var email: String
    var name: String
    var phoneNumber: String
    var imageUser: String //extension for getting date
    var id: String
    var address: String
    
    init(email: String, phoneNumber: String, name: String, imageUser: String, id: String, address: String) {
        self.email = email
        self.name = name
        self.phoneNumber = phoneNumber
        self.imageUser = imageUser
        self.id = id
        self.address = address
    }
}

var employees: [Employee] =
    [Employee.init(email: "rahul.sharma@tothenew.com", employeeId: "1", fName: "Rahul", address: "Delhi"),
     Employee.init(email: "aryan@tothenew.com", employeeId: "2", fName: "Aryan", address: "Delhi"),
     Employee.init(email: "kavya@tothenew.com", employeeId: "3", fName: "Kavya", address: "Delhi"),
     Employee.init(email: "harsh@tothenew.com", employeeId: "4", fName: "Harsh", address: "Delhi"),
     Employee.init(email: "vijender@tothenew.com", employeeId: "5", fName: "Vijender", address: "Delhi")]

class  EmployeeClass {
    static let shared = EmployeeClass()
    
    private init(){}
    
    var objOfEmployee : [Employee] = employees
}


class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func pressedToGoToFirstVC(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(identifier: "First") as! FirstViewController
        vc.navigationItem.largeTitleDisplayMode = .never
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    @IBAction func pressedToGoToSecondVC(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(identifier: "Second") as! SecondViewController
        vc.navigationItem.largeTitleDisplayMode = .never
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func pressedToGoToThirdVC(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(identifier: "Third") as! ThirdViewController
        vc.navigationItem.largeTitleDisplayMode = .never
        navigationController?.pushViewController(vc, animated: true)
    }
    
}

