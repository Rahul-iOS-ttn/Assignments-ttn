//
//  FirstViewController.swift
//  Singleton_application
//
//  Created by TTN on 26/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var myTable: UITableView!
    
    
    
    var firstVCEmployee = EmployeeClass.shared.objOfEmployee
    

    
       override func viewDidLoad() {
           super.viewDidLoad()
           // Do any additional setup after loading the view.
        myTable.register(MyCustomTableViewCell.nib(), forCellReuseIdentifier: MyCustomTableViewCell.identifier)
        
           myTable.delegate = self
           myTable.dataSource = self
       }
    
       func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return firstVCEmployee.count
         }
         
         func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

           
           let cell = myTable.dequeueReusableCell(withIdentifier: MyCustomTableViewCell.identifier, for: indexPath) as! MyCustomTableViewCell
           
           cell.configureMyFunction1(element: firstVCEmployee[indexPath.row])
           return cell
         }
}
