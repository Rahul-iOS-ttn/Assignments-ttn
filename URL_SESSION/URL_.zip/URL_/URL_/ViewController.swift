//
//  ViewController.swift
//  URL_
//
//  Created by TTN on 14/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBAction func GetButton(_ sender: Any) {
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        let url = URL(string: "https://jsonplaceholder.typicode.com/posts/")!
        
        let task = session.dataTask(with: url) { data, response, error in

               guard error == nil else {
                   print ("error: \(error!)")
                   return
               }
               
               guard let content = data else {
                   print("No data")
                   return
               }
               
               guard let json = (try? JSONSerialization.jsonObject(with: content, options: JSONSerialization.ReadingOptions.mutableContainers)) as? [[String: Any]] else {
                   print("Not containing JSON content")
                   return
               }
               
               print("json response dictionary is \n \(json)")
           }
        task.resume()
    }
    
    @IBAction func PostButton(_ sender: Any) {
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)

        guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts") else {
            return
        }
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"

        let postDict : [String: Any] = ["postId": 99, "name": "Rahul Sharma", "email": "rahul@sharma.com", "id": 99, "body":" This will be the assignment for URL session" ]

        guard let postData = try? JSONSerialization.data(withJSONObject: postDict, options: []) else {
            return
        }

        urlRequest.httpBody = postData

        let task = session.dataTask(with: urlRequest) { data, response, error in
            
            guard error == nil else {
                print ("error: \(error!)")
                return
            }
    
            guard let content = data else {
                print("No data")
                return
            }
            
            guard let json = (try? JSONSerialization.jsonObject(with: content, options: JSONSerialization.ReadingOptions.mutableContainers)) as? [String: Any] else {
                print("Not containing JSON content")
                return
            }
            print("json response dictionary is \n \(json)")
        }
        task.resume()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}
