//
//  SecondViewController.swift
//  BootCamp
//
//  Created by TTN on 24/02/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    @IBOutlet weak var popToRoot: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
   view.backgroundColor = .white
            setupNavigationBar()
            // Do any additional setup after loading the view.
        }
        private func setupNavigationBar() {
                navigationController?.navigationBar.backgroundColor = .black
                navigationController?.navigationBar.isTranslucent = false
                
                setupNavigationBarItems()
            }
            
            private func setupNavigationBarItems() {
                navigationItem.title = "Path screen"
                
                setupLeftNavigationBar()
                setupRightNavigationBar()
            }
         private func setupLeftNavigationBar() {
                let sunsetButton = UIButton(type: .system)
                sunsetButton.setImage(UIImage(named: "sunset (1).png"), for: .normal)
                
                navigationItem.leftBarButtonItem = UIBarButtonItem(customView: sunsetButton)
            }
            
            private func setupRightNavigationBar() {
                let landscapeButton = UIButton(type: .system)
                landscapeButton.setImage(UIImage(named: "landscape (1).png"), for: .normal)
                
                navigationItem.rightBarButtonItems = [UIBarButtonItem(customView: landscapeButton)]
            }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    @IBAction func rootPath() {
        self.navigationController!.popToRootViewController(animated: true)
    }
    
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
