import UIKit

var str = "Hello, playground"

struct employee_personal{
    var employee_id = 12
    var name : String
    var country : String // this will become the common ID
    var address : String
    var hobbies : String
}

struct employee_professional{
    var employee_ID : Int
    var name : String
    var department : String
    var branch : String // this will become the common ID
    var experience : Int
}

struct employee_common{
    var employee_common_id : String
//    var e_P = employee_personal()
//    var e_Pro = employee_professional()
}

let a = employee_personal(employee_id: 1, name: "rahul", country: "India", address: "delhi", hobbies: "music")

let b = employee_personal(name: "alex", country: "america", address: "washington", hobbies: "basketball")

a
b

