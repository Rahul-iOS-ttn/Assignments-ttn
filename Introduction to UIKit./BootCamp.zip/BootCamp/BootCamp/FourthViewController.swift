//
//  FourthViewController.swift
//  BootCamp
//
//  Created by TTN on 03/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit
import SwiftUI

class FourthViewController: UIViewController {

    @IBOutlet weak var dismissButton: UIButton!
    @IBOutlet weak var textSegueLabel: UILabel!
    var data = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        print(data)
        textSegueLabel.text = data
        view.backgroundColor = .white
            setupNavigationBar()
            // Do any additional setup after loading the view.
        }
        private func setupNavigationBar() {
                navigationController?.navigationBar.backgroundColor = .black
                navigationController?.navigationBar.isTranslucent = false
                
                setupNavigationBarItems()
            }
            
            private func setupNavigationBarItems() {
                navigationItem.title = "Path screen"
                
                setupLeftNavigationBar()
                setupRightNavigationBar()
            }
         private func setupLeftNavigationBar() {
                let sunsetButton = UIButton(type: .system)
                sunsetButton.setImage(UIImage(named: "sunset (1).png"), for: .normal)
                
                navigationItem.leftBarButtonItem = UIBarButtonItem(customView: sunsetButton)
            }
            
            private func setupRightNavigationBar() {
                let landscapeButton = UIButton(type: .system)
                landscapeButton.setImage(UIImage(named: "landscape (1).png"), for: .normal)
                
                navigationItem.rightBarButtonItems = [UIBarButtonItem(customView: landscapeButton)]
            }
    @IBAction func dismissScreen () {
        view.window?.rootViewController?.dismiss(animated: true, completion: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    

}
