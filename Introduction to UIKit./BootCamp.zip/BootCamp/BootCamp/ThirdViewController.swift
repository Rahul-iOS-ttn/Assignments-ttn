//
//  ThirdViewController.swift
//  BootCamp
//
//  Created by TTN on 03/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {
//    var label: String!
    @IBOutlet weak var dismissButton: UIButton!
    @IBOutlet weak var presentButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
            setupNavigationBar()
            // Do any additional setup after loading the view.
        }
        private func setupNavigationBar() {
                navigationController?.navigationBar.backgroundColor = .black
                navigationController?.navigationBar.isTranslucent = false
                
                setupNavigationBarItems()
            }
            
            private func setupNavigationBarItems() {
                navigationItem.title = "Path screen"
                
                setupLeftNavigationBar()
                setupRightNavigationBar()
            }
         private func setupLeftNavigationBar() {
                let sunsetButton = UIButton(type: .system)
                sunsetButton.setImage(UIImage(named: "sunset (1).png"), for: .normal)
                
                navigationItem.leftBarButtonItem = UIBarButtonItem(customView: sunsetButton)
            }
            
            private func setupRightNavigationBar() {
                let landscapeButton = UIButton(type: .system)
                landscapeButton.setImage(UIImage(named: "landscape (1).png"), for: .normal)
                
                navigationItem.rightBarButtonItems = [UIBarButtonItem(customView: landscapeButton)]
            }
    
    @IBAction func dismissScreen () {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func firstPresentButtonTapped() {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "FourthViewController")
            let vc3 = UINavigationController.init(rootViewController: vc)
    //        vc.label = "Rahul"
            self.present(vc3, animated: true, completion: nil)
    //        navigationController?.pushViewController(vc, animated: true)
        }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
