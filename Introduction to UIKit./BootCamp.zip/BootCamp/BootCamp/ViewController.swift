//
//  ViewController.swift
//  BootCamp
//
//  Created by TTN on 17/02/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

//protocol DataTransfer : class{
//    func valueTransfer(_ value: String)
//}

class ViewController: UIViewController {
    
    
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var sendButton: UIButton!
    @IBOutlet weak var emailTextField: UITextField!
//    weak var dataTransfer: DataTransfer?
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //        loginButton.setTitle("Rahul", for: .normal)
    }
    
    
    
    @IBAction func loginButtonTapped() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "FirstViewController")
//                self.present(vc, animated: true)
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func sendData() {
//        guard let data = emailTextField.text else {return}
//        dataTransfer?.valueTransfer(data ?? "nothing")
//
        let fvc = storyboard?.instantiateViewController(withIdentifier: "FourthViewController") as! FourthViewController
        navigationController?.pushViewController(fvc, animated: true)
//        fvc.dataTransfer = self
//        prepare(for: UIStoryboardSegue., sender: Any?)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let fvc = segue.destination as? FourthViewController {
//            fvc.data = emailTextField.text ?? ""
            fvc.data = emailTextField.text ?? ""
        }
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }
}

