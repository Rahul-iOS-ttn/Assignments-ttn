//
//  FirstViewController.swift
//  BootCamp
//
//  Created by TTN on 24/02/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {
    @IBOutlet weak var firstMoveForwardButton: UIButton!
    @IBOutlet weak var firstMoveBackwardButton: UIButton!
    @IBOutlet weak var firstMovePresentButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupNavigationBar() // Navigation bar customizations
        // Do any additional setup after loading the view.
    }
    private func setupNavigationBar() {
            navigationController?.navigationBar.backgroundColor = .green
            navigationController?.navigationBar.isTranslucent = false
            
            setupNavigationBarItems()
        }
        
        private func setupNavigationBarItems() {
            navigationItem.title = "Path screen"
            
            setupLeftNavigationBar()
            setupRightNavigationBar()
        }
     private func setupLeftNavigationBar() {
            let sunsetButton = UIButton(type: .system)
            sunsetButton.setImage(UIImage(named: "sunset (1).png"), for: .normal)
            
            navigationItem.leftBarButtonItem = UIBarButtonItem(customView: sunsetButton)
        }
        
        private func setupRightNavigationBar() {
            let landscapeButton = UIButton(type: .system)
            landscapeButton.setImage(UIImage(named: "landscape (1).png"), for: .normal)
            
            navigationItem.rightBarButtonItems = [UIBarButtonItem(customView: landscapeButton)]
        }
    @IBAction func firstMoveForwardButtonTapped() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "SecondViewController")
        //        self.present(vc, animated: true)
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func firstMoveBackwardButtonTapped() {
        navigationController?.popViewController(animated: true)
    }
    @IBAction func firstMovePresentButtonTapped() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "ThirdViewController")
        let vc3 = UINavigationController.init(rootViewController: vc)
//        vc.label = "Rahul"
        self.present(vc3, animated: true, completion: nil)
//        navigationController?.pushViewController(vc, animated: true)
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
}
